import React from 'react'
import { Link } from 'react-router-dom';

export default function ListGames({ games, page, changePage }) {
    console.log("games", games);
    return (
        <div>
            <center style={{ display: 'flex', flexDirection: 'row', width: '100%', margin: 20, flexWrap: 'wrap', justifyContent: 'center' }}>
                {
                    //map recorre el arreglo y nos devuelve cada uno de los juegos en game 
                    games.map(game => {
                        return (
                            <div style={{ width: '20%', margin: 8 }}>
                                <Link to={'/detail?id=' + game.id}>
                                    <img src={game.background_image} style={{ width: '100%', }} />
                                    <h4>{game.name}</h4>
                                    <h4>{game.rating}</h4>
                                </Link>
                            </div>
                        );
                    })
                }
            </center>
            {page && <div style={{ display: 'flex', flexDirection: 'row', width: '100%', margin: 20, flexWrap: 'wrap', justifyContent: 'center' }}>
                <button
                    onClick={
                        () => {
                            changePage(page - 1)
                        }
                    }
                >
                    Anterior
                </button>
                <button
                    onClick={
                        () => {
                            changePage(page + 1)
                        }
                    }
                >
                    Siguiente
                </button>
            </div>}
        </div>
    )
}
