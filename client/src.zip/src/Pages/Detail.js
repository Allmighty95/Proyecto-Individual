import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as actionsCreators from '../redux/actions';

function Detail({ state, id, fetchGameById }) {

    const { loadinGameById, gameDetail } = state;

    useEffect(() => {
        fetchGameById(id)
    }, [])

    return (
        <div>
            {
                (!loadinGameById && gameDetail.name) &&
                <div>{gameDetail.name}</div>
            }
        </div>
    )
}

const mapStateToProps = (state) => ({ state });

function mapDispatchToProps(dispatch) {
    return bindActionCreators(actionsCreators, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Detail);
