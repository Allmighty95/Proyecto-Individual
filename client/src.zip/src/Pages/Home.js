import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as actionsCreators from '../redux/actions';
import ListGames from '../utils/ListGames';


function Home({ state, fetchGames, fetchGamesByName, fetchGenres, fetchCreatedGames }) {

    const { games, loading, loadingSearch, foundGames, genres, createdGames } = state

    const [filteredGames, setFilteredGames] = useState([])

    const [ascending, setAscending] = useState(false)

    const [page, setPage] = useState(1)

    useEffect(() => {
        fetchCreatedGames()
        if (games.length < 1) {
            extractData(1)
            fetchGenres()
        }
    }, [])

    const extractData = (p) => {
        setPage(p)
        fetchGames(page)
    }

    var searchValue = ""

    const searchGames = () => {
        fetchGamesByName(searchValue)
    }

    const filterGames = ({ filter, payload }) => {
        let newFilteredGames
        switch (filter) {
            case 'genre':
                newFilteredGames = payload != "Seleccionar un genero" ?
                    games.filter(game => game.genres.some(genre => genre.name == payload))
                    : games
                setFilteredGames(newFilteredGames)
                break;
            case 'name':
                console.log("entra aqui");
                newFilteredGames =
                    games.sort(function (a, b) {
                        if (a.name < b.name) { return -1; }
                        if (a.name > b.name) { return 1; }
                        return 0;
                    })
                setFilteredGames(newFilteredGames)
            case 'rating':
                newFilteredGames =
                    games.slice()
                        .sort((a, b) => payload == true ?
                            a.rating + b.rating
                            : a.rating - b.rating
                        )
                setFilteredGames(newFilteredGames)
            default:
                break;

        }

    }

    return (
        <div>
            {/* Input de busqueda */}
            <input type="text" onChange={(event) => {
                searchValue = event.target.value;
            }} />

            {/* Boton de buscar */}
            <button onClick={() => { searchGames(1) }}>
                Buscar
            </button>

            {/* Dropdown de los generos */}
            <select onChange={(event) => {
                filterGames({ filter: 'genre', payload: event.target.value });
            }} name="genre" id="genre">
                <option value={null} >Seleccionar un genero</option>
                {
                    genres.map(genre => {
                        return (
                            <option value={genre.name}>{genre.name}</option>
                        );
                    })
                }
            </select>

            {/* Boton de rating */}
            <button onClick={() => {
                setAscending(!ascending)
                filterGames({ filter: 'name', payload: ascending })
            }}>
                Ordenar por nombre
                {ascending ? " ascendente" : " descendente"}
            </button>

            {/* Boton de rating */}
            <button onClick={() => {
                setAscending(!ascending)
                filterGames({ filter: 'rating', payload: ascending })
            }}>
                Ordenar por rating
                {ascending ? " ascendente" : " descendente"}
            </button>

            {/* Juegos Creados */}
            {
                createdGames.length >= 1 &&
                < div >
                    <h1>Creados por el usuario</h1>
                    {
                        loadingSearch ? "Cargando..." : <ListGames games={createdGames} />
                    }
                </div>
            }
            {/* Juegos Encontrados */}
            {
                foundGames.length >= 1 &&
                < div >
                    <h1>Resultados de la busqueda</h1>
                    {
                        loadingSearch ? "Cargando..." : <ListGames games={foundGames} />
                    }
                </div>
            }
            {/* Juegos Por Defecto */}
            {
                <div>
                    <h1>Los Jueguitos de sam</h1>
                    {loading ? "Cargando..." : <ListGames games={filteredGames.length > 1 ? filteredGames : games} page={page} changePage={extractData} />}
                </div>
            }
        </div >
    )
}


const mapStateToProps = (state) => ({
    state,
});

function mapDispatchToProps(dispatch) {
    return bindActionCreators(actionsCreators, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Home);
