import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as actionsCreators from '../redux/actions';

function CreateGame({ state, fetchGenres }) {

    const [data, setData] = useState({
        name: "",
        description: "",
        releasedate: "",
        rating: 0,
        platforms: "",
        gender: 1,
        platforms: "",
        genres: []
    })




    const { genres } = state

    const platforms = [
        "PC",
        "IOS",
        "Android",
        "MacOS",
        "PlayStation 4",
        "Xbox X",
        "Xbox",
        "PS vita"
    ]

    useEffect(() => {
        fetchGenres()
    })

    const formPreventDefault = (e) => {
        console.log("data de peticion", JSON.stringify(data));
        fetch('http://localhost:3001/videogame', {
            method: 'POST',
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'application/json'
            },
        }).then(async res => {
            let jsonReposponse = await res.json()
            console.log("res", jsonReposponse);
        }).catch(err => {
            console.log("err", err);
        })
        e.preventDefault();
    }

    return (

        <div>
            {/* Formulario */}
            <h1>Crea tu Videojuego!</h1>
            <form onSubmit={formPreventDefault}>

                {/* Nombre de juego */}
                <label>Nombre del Juego</label>
                <input onChange={(event) => {
                    setData({ ...data, name: event.target.value })
                }} type="text" name="name" />

                {/* Descripcion */}
                <label>Descripcion</label>
                <input onChange={(event) => {
                    setData({ ...data, description: event.target.value })
                }} type="text" name="descripcion"></input>

                {/* Fecha de lanzamiento */}
                <label>Fecha de Lanzamiento</label>
                <input onChange={(event) => {
                    setData({ ...data, releasedate: event.target.value })
                }} class="label" type="date" name="Fecha" value="2021-09-22" />

                {/* Rating */}
                <label>rating</label>
                <input onChange={(event) => {
                    setData({ ...data, rating: event.target.value })
                }} class="label" type="number" name="Rating" />

                {/* Generos */}
                <div class="checks">
                    <h3>Generos</h3>
                    {genres.map(genre => {
                        return (
                            <div>
                                <label>{genre.name}</label>
                                <input onChange={(event) => {
                                    if (event.target.checked) {
                                        data.genres.push(genre.name);
                                    }
                                    else {
                                        const index = data.genres.indexOf(genre.name);
                                        if (index !== -1) { data.genres.splice(index, 1); }
                                    }
                                }} type="checkbox" />
                            </div>
                        )
                    })}

                    {/* Plataformas */}
                    <h3>Plataformas</h3>
                    {
                        platforms.map(platform => {
                            return (
                                <div>
                                    <label>{platform}</label>
                                    <input onChange={(event) => {
                                        if (event.target.checked) {
                                            data.platforms.push(platform);
                                        }
                                        else {
                                            const index = data.platforms.indexOf(platform);
                                            if (index !== -1) { data.platforms.splice(index, 1); }
                                        }
                                    }} type="checkbox" />
                                </div>
                            )
                        })
                    }
                    <button class="button" type="submit">Crear VideoJuego!</button>
                </div >
            </form >
        </div >
    )
}
const mapStateToProps = (state) => ({
    state,
});

function mapDispatchToProps(dispatch) {
    return bindActionCreators(actionsCreators, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(CreateGame);






