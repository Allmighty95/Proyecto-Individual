import { Provider } from 'react-redux';
import {
  BrowserRouter as Router, Link, Route, Switch, useLocation
} from "react-router-dom";
import CreateGame from './Pages/CreateGame';
import Detail from './Pages/Detail';
import Home from './Pages/Home';
import store from './redux/store/store';

//https://reactrouter.com/web/example/query-parameters
function useQuery() {
  return new URLSearchParams(useLocation().search);
}

export default function App() {
  return (
    <Provider store={store}>
      <Router>
        <RoutesWithQuery />
      </Router>
    </Provider>
  )
}

function RoutesWithQuery() {
  const query = useQuery();

  return (
    <div>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>

          <li>
            <Link to="/create">Crear un Juego</Link>
          </li>
        </ul>
      </nav>
      <Switch>

        <Route exact path="/">
          <Home />
        </Route>

        <Route exact path="/create">
          <CreateGame />
        </Route>

        <Route exact path="/detail">
          <Detail id={query.get('id')} />
        </Route>

      </Switch>
    </div>
  )
}
