export function getGamesAll() {
    return {
        type: 'GET_ALL_GAMES',
    }
}

export function getGamesSearch() {
    return {
        type: 'GET_SEARCH_GAMES',
    }
}

export function getCreatedGames() {
    return {
        type: 'GET_CREATED_GAMES',
    }
}

export function receiveGames(games) {
    return {
        type: 'RECEIVE_GAMES',
        games
    }
}

export function receiveFoundGames(games) {
    return {
        type: 'RECEIVE_FOUND_GAMES',
        games
    }
}

export function receiveCreatedGames(games) {
    return {
        type: 'RECEIVE_CREATED_GAMES',
        games
    }
}

export function receiveGenres(genres) {
    return {
        type: 'RECEIVE_GENRES',
        genres
    }
}

export function loadingGameById() {
    return {
        type: 'LOADING_GAME_BY_ID',
    }
}

export function receiveGameById(game) {
    return {
        type: 'RECEIVE_GAME_BY_ID',
        game
    }
}

export function fetchGames(page) {
    return function (dispatch) {
        dispatch(getGamesAll())
        const api = "https://api.rawg.io/api/games?key=43b626b72d574caf83f1b2cae0216122" + "&page=" + page
        fetch(api)
            .then(async res => {
                const respuestaEnJson = await res.json()
                dispatch(receiveGames(respuestaEnJson.results))
            })
            .catch(e => console.log(e));
    }
}


export function fetchGamesByName(name) {
    return function (dispatch) {
        dispatch(getGamesSearch())
        let allResults = []
        //Api local
        const localApi = "http://localhost:3001/videogames?name=" + name
        fetch(localApi)
            .then(async res => {
                const respuestaEnJson = await res.json()
                allResults = allResults.concat(respuestaEnJson.results)

            })
            .catch(e => console.log(e));
        // Api rawg
        const api = "https://api.rawg.io/api/games?key=43b626b72d574caf83f1b2cae0216122" + "&search=" + name
        fetch(api)
            .then(async res => {
                const respuestaEnJson = await res.json()
                allResults = allResults.concat(respuestaEnJson.results)
                dispatch(receiveFoundGames(allResults))
            })
            .catch(e => console.log(e));

    }
}

export function fetchGenres() {
    return function (dispatch) {
        const api = "https://api.rawg.io/api/genres?key=43b626b72d574caf83f1b2cae0216122"
        fetch(api)
            .then(async res => {
                const respuestaEnJson = await res.json()
                dispatch(receiveGenres(respuestaEnJson.results))
            })
            .catch(e => console.log(e));
    }
}

export function fetchCreatedGames() {
    return function (dispatch) {
        dispatch(getGamesSearch())
        const api = "http://localhost:3001/videogames"
        fetch(api)
            .then(async res => {
                const respuestaEnJson = await res.json()
                dispatch(receiveFoundGames(respuestaEnJson.results))
                console.log("Created Games respuestaEnJson", respuestaEnJson);
            })
            .catch(e => console.log(e));
    }
}

export function fetchGameById(id) {
    return function (dispatch) {
        dispatch(loadingGameById())
        const api = "http://localhost:3001/videogames/" + id
        fetch(api)
            .then(async res => {
                const respuestaEnJson = await res.json()
                dispatch(receiveGameById(respuestaEnJson.data))
            })
            .catch(e => console.log(e));
    }
}